
document.querySelector(".container").appendChild(createNode());




function createNode() {
    let e_0 = document.createElement("table");
    e_0.setAttribute("class", "table");
    let e_1 = document.createElement("thead");
    let e_2 = document.createElement("tr");
    let e_3 = document.createElement("th");
    e_3.appendChild(document.createTextNode("Id"));
    e_2.appendChild(e_3);
    let e_4 = document.createElement("th");
    e_4.appendChild(document.createTextNode("name"));
    e_2.appendChild(e_4);
    let e_5 = document.createElement("th");
    e_5.appendChild(document.createTextNode("prijs"));
    let e_6 = document.createElement("th");
    e_6.appendChild(document.createTextNode("afbeelding"));
    let e_7 = document.createElement("th");
    let e_8 = document.createElement("th");
    e_2.appendChild(e_6);
    e_2.appendChild(e_5);
    e_2.appendChild(e_7);
    e_2.appendChild(e_8);
    e_1.appendChild(e_2);
    e_0.appendChild(e_1);
    fetch('/product.json')
        .then((response) => response.json())
        .then((response) => {
            for (const key in response) {
                e_0.appendChild(bd(key,response));
            }
        })
    return e_0
}

function bd(index,response) {
    let e_7 = document.createElement("tbody");
    let e_8 = document.createElement("tr");
    let e_9 = document.createElement("td");
    console.log(response);
    e_9.appendChild(document.createTextNode(response[index].id));
    e_8.appendChild(e_9);
    let e_10 = document.createElement("td");
    e_10.appendChild(document.createTextNode(response[index].productnaam));

    e_8.appendChild(e_10);
    let e_11 = document.createElement("td");
    e_11.appendChild(document.createTextNode(response[index].afbelding));
    let e_12 = document.createElement("td");
    e_12.appendChild(document.createTextNode(response[index].prijs));


    let e_13 = document.createElement("td");
    let e_13_a=document.createElement('a');
    e_13_a.textContent='Edit';
    e_13_a.id=index
    e_13_a.setAttribute('href',`/edit/${e_13_a.id}`);
    e_13_a.style.textDecoration='none'
    e_13.appendChild(e_13_a);

    let e_14 = document.createElement("td");
    let e_14_a=document.createElement('a');
    e_14_a.textContent='Remove';
    e_14_a.style.color='red'
    e_14_a.style.textDecoration='none'
    e_14_a.id=index
    e_14_a.setAttribute('href', `/remove/${e_13_a.id}`);
    e_14.appendChild(e_14_a);
    e_8.appendChild(e_11);
    e_8.appendChild(e_12);
    e_8.appendChild(e_13);
    e_8.appendChild(e_14);
    e_7.appendChild(e_8);
    return e_7
}
function reset(){
    fetch('/reset')
    .then(()=>{
        window.location.reload()
    })
}