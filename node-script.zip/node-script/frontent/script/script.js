let winkelwagen = document.querySelector('#winkelwagen');
fetch('/storage')
function checkbal() {
    fetch('winkelwagen.json')
        .then(response => response.json())
        .then((response) => {
            let flag = false;
            //userid is hier een voorbeeld, als een inlogsys heb gemaakt dan replace het met variable!
            if (Object.keys(response.userid1.totalproduct).length != 0) {
                for (let i in response.userid1.totalproduct) {
                    if (response.userid1.totalproduct[i].afzet != 0) {
                        flag = true
                        console.log(response.userid1.totalproduct[i].afzet);
                    } else if (!(flag)) {
                        console.log('this is 0' + i);
                    }
                }
                if (flag) {
                    winkelwagen.style.visibility = 'visible';
                } else {
                    winkelwagen.style.visibility = 'hidden';
                }
            }
            console.log(response);
        })
}
checkbal()

function createNode(key) {
    var e_1 = document.createElement("div");
    e_1.setAttribute("class", "col-5 d-flex justify-content-center");
    var e_2 = document.createElement("div");
    e_2.setAttribute("class", "card");
    e_2.setAttribute("style", "width: 100%;");
    var e_3 = document.createElement("img");
    e_3.style.maxHeight = '300px';
    e_3.setAttribute("src", key.afbelding);
    e_3.setAttribute("class", "card-img-top");
    e_3.setAttribute("alt", "...");
    e_2.appendChild(e_3);
    var e_4 = document.createElement("div");
    e_4.setAttribute("class", "card-body");
    var e_5 = document.createElement("ul");
    e_5.setAttribute("class", "list-group list-group-flush");
    var e_6 = document.createElement("li");
    e_6.setAttribute("class", "list-group-item text-center");
    e_6.appendChild(document.createTextNode(key.prijs));
    e_5.appendChild(e_6);
    var e_7 = document.createElement("li");
    e_7.setAttribute("class", "list-group-item text-center");
    e_7.appendChild(document.createTextNode(key.productnaam));
    e_5.appendChild(e_7);
    var e_8 = document.createElement("li");
    e_8.setAttribute("class", "list-group-item");
    var e_9 = document.createElement("button");
    e_9.setAttribute("onclick", "add(event)");
    e_9.setAttribute("class", "w-100 h-100 btn btn-primary me-md-2");
    e_9.appendChild(document.createTextNode("voeg in\nwinkel wagen\n"));
    e_8.appendChild(e_9);
    e_5.appendChild(e_8);
    e_4.appendChild(e_5);
    e_2.appendChild(e_4);
    e_1.appendChild(e_2);
    return e_1;
}
function row() {
    var e_0 = document.createElement("div");
    e_0.setAttribute("class", "row d-flex justify-content-center");
    return e_0
}
fetch('../product.json')
    .then((response) => response.json())
    .then((response) => {
        let count = 0
        let pt= row()
        for (const key in response) {
            pt.appendChild(createNode(response[key]))
            count++
            if (count == 2) {
                document.querySelector('#container').appendChild(pt)
                count = 0
            }
        }
    })


function add(event) {
    const button = event.currentTarget;
    const listItem = button.parentNode.previousElementSibling;
    const text = listItem.textContent.trim();
    fetch(`userid1/add/${text}/`)
        .then(() => {
            let scrol = window.scrollY
            location.reload()
            window.scrollTo(0, scrol)
        })
}