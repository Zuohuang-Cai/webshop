let ary = 0
fetch('../user.json')
    .then(response => response.json())
    .then((response) => {
        console.log(response);
        ary = response.length;
        document.querySelector(".container").appendChild(createNode());
    })
function createNode() {
    let e_0 = document.createElement("table");
    e_0.setAttribute("class", "table");
    let e_1 = document.createElement("thead");
    let e_2 = document.createElement("tr");
    let e_3 = document.createElement("th");
    e_3.appendChild(document.createTextNode("Id"));
    e_2.appendChild(e_3);
    let e_4 = document.createElement("th");
    e_4.appendChild(document.createTextNode("Total Prijs"));
    e_2.appendChild(e_4);
    let e_5 = document.createElement("th");
    e_5.appendChild(document.createTextNode("Tijd"));
    e_2.appendChild(e_5);
    e_1.appendChild(e_2);
    e_0.appendChild(e_1);

    for (let index = 0; index < ary; index++) {
        e_0.appendChild(bd(index));
    }
    return e_0;
}

function bd(index) {
    let e_7 = document.createElement("tbody");
    let e_8 = document.createElement("tr");
    let e_9 = document.createElement("td");
    fetch('../user.json')
        .then(response => response.json())
        .then((response) => {
            console.log(response);
            e_9.appendChild(document.createTextNode(response[index][0].id));
            e_8.appendChild(e_9);
            let e_10 = document.createElement("td");
            e_10.appendChild(document.createTextNode(response[index][1].total));

            e_8.appendChild(e_10);
            let e_11 = document.createElement("td");
            e_11.appendChild(document.createTextNode(response[index][2].datum));
            e_8.appendChild(e_11);
            e_7.appendChild(e_8);
            return e_7
        })
    return e_7
}
