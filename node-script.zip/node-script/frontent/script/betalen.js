let ary = [];
fetch('../winkelwagen.json')
  .then(response => response.json())
  .then((response) => {
    for (const key1 in response.userid1.totalproduct) {
      console.log(key1);
      ary.push(key1)
    }
    return response
  })
  .then((response) => {
    let totalprijs = 0;
    let cont = document.querySelector('#betalencontainer')
    cont.appendChild(createNode());
    for (const key in response.userid1.totalproduct) {
      totalprijs += (parseFloat(response.userid1.totalproduct[key].prijs) * parseFloat(response.userid1.totalproduct[key].afzet));
    }
    cont.appendChild(total(totalprijs))
    cont.appendChild(bt())
  })

function bt() {
  let e_0 = document.createElement("a");
  e_0.setAttribute("class", "btn btn-primary w-100");
  e_0.setAttribute("href", "afrekenen.html");
  e_0.setAttribute("onclick", "append_user_total()");
  e_0.setAttribute("role", "button");
  e_0.appendChild(document.createTextNode("afrekenen"));
  return e_0;
}

function clearall() {
  fetch('/clear/all')
  location.reload()
}

function total(prijs) {
  let e_0 = document.createElement("div");
  e_0.setAttribute("class", "d-flex flex-row mb-3 justify-content-between");
  let e_1 = document.createElement("span");
  e_1.appendChild(document.createTextNode("total"));
  e_0.appendChild(e_1);
  let e_2 = document.createElement("span");
  e_2.appendChild(document.createTextNode(prijs));
  e_2.id="totalprijs"
  e_0.appendChild(e_2);
  return e_0;
}


function append_user_total() {
  let prijs = document.querySelector('#totalprijs').textContent
  if (prijs!="0") {
    fetch(`/user/id/${prijs}/tijd`);
  }
}



function createNode() {
  let e_0 = document.createElement("table");
  e_0.setAttribute("class", "table");
  let e_1 = document.createElement("thead");
  let e_2 = document.createElement("tr");
  let e_3 = document.createElement("th");
  e_3.appendChild(document.createTextNode("Product"));
  e_2.appendChild(e_3);
  let e_4 = document.createElement("th");
  e_4.appendChild(document.createTextNode("prijs"));
  e_2.appendChild(e_4);
  let e_5 = document.createElement("th");
  e_5.appendChild(document.createTextNode("afzet"));
  e_2.appendChild(e_5);
  let e_6 = document.createElement("th");
  e_6.appendChild(document.createTextNode("total"));
  e_2.appendChild(e_6);
  e_1.appendChild(e_2);
  e_0.appendChild(e_1);

  ary.forEach((value, index) => {
    console.log(value);
    e_0.appendChild(bd(value));
  })
  return e_0;
}

function bd(key) {
  let e_7 = document.createElement("tbody");
  let e_8 = document.createElement("tr");
  let e_9 = document.createElement("td");
  fetch('../winkelwagen.json')
    .then(response => response.json())
    .then((response) => {
      if (response.userid1.totalproduct[key].afzet != 0) {
        console.log(response.userid1.totalproduct[key].afzet);
        console.log(response);
        e_9.appendChild(document.createTextNode(response.userid1.totalproduct[key].productnaam));
        e_8.appendChild(e_9);
        let e_10 = document.createElement("td");
        e_10.appendChild(document.createTextNode(response.userid1.totalproduct[key].prijs));

        e_8.appendChild(e_10);
        let e_11 = document.createElement("td");
        e_11.appendChild(document.createTextNode(response.userid1.totalproduct[key].afzet));
        e_8.appendChild(e_11);
        let e_12 = document.createElement("td");
        e_12.appendChild(document.createTextNode(response.userid1.totalproduct[key].prijs * response.userid1.totalproduct[key].afzet));
        e_8.appendChild(e_12);
        e_7.appendChild(e_8);
        return e_7
      }
      return e_7 = undefined;
    })
  return e_7
}