const { count, dir } = require('console');
const fs = require('fs');
const http = require('http');
const { dirname } = require('path');


const server = http.createServer((request, response) => {
    const { pathname } = new URL(request.url, 'http://127.0.0.1:9000');
    const readurl = __dirname + "/frontent" + pathname;

    // console.log("request url is : " + request.url);
    // console.log("path name is : " + pathname);
    // console.log('full path is : '+readurl);
    let regex = request.url.match(/^\/userid1\/add\/(.*)/i);
    let regex1 = request.url.match(/\/user\/id\/(.*)\/tijd/i);
    let regex2 = request.url.match(/\/edit\/(.*)/i)
    let regex3 = request.url.match(/\/edit\/(.*)/i)
    let regex4 = request.url.match(/\/remove\/(.*)/i)
    if (regex) {
        let filepath = __dirname + '/frontent/winkelwagen.json'
        fs.readFile(filepath, (error, data) => {
            if (error) {
                console.error('Error reading JSON file:', error);
                return;
            }
            console.log(regex);
            let dynamicValue = regex[1].replace("/", '')
            dynamicValue = dynamicValue.replace(/%20/g, ' ')
            console.log(dynamicValue);
            let json_content = JSON.parse(data.toString())
            if (!(dynamicValue in json_content.userid1.totalproduct)) {
                fs.readFile(__dirname + '/frontent/product.json', (error, data) => {
                    if (error) {
                        console.log(error);
                        return;
                    }
                    data = JSON.parse(data.toString());
                    json_content.userid1.totalproduct[dynamicValue] = {
                        "productnaam": dynamicValue,
                        "UserProductid": "34",
                        "prijs": data[dynamicValue].prijs,
                        "afzet": 1
                    }
                    fs.writeFile(__dirname + '/frontent/winkelwagen.json', JSON.stringify(json_content, null, 2), (error) => {
                        if (error) {
                            console.log(error);
                            return;
                        }
                        response.end('succes added')
                    })
                })
            } else {
                json_content.userid1.totalproduct[dynamicValue].afzet += 1;
                fs.writeFile(filepath, JSON.stringify(json_content, null, 2), (error) => {
                    if (error) {
                        console.log(error);
                        return;
                    }
                    response.end('succes updated.')
                })
            }
        })
    } else if (pathname == "/") {
        fs.readFile(readurl + "index.html", (error, data) => {
            if (error) {
                response.statusCode = 404;
                response.end(error.message);
            } else {
                response.end(data);
            }
        });
    } else if (pathname == "/admin/toevoegen") {
        let formData = '';

        request.on('data', (chunk) => {
            formData += chunk;
        });

        request.on('end', () => {
            const parsedFormData = new URLSearchParams(request.url);
            console.log(parsedFormData);
            const name = parsedFormData.get('/admin/toevoegen?name');
            const prijs = parsedFormData.get('prijs');
            const afbeelding = parsedFormData.get('afbeelding');
            console.log(prijs);
            console.log(afbeelding);
            console.log(name);
            let filepath = __dirname + '/frontent/product.json'
            fs.readFile(filepath, (error, data) => {
                if (error) {
                    console.error('Error reading JSON file:', error);
                    return;
                }
                let json_content = JSON.parse(data.toString())

                subobject = {
                    "id": Object.keys(json_content).length,
                    "productnaam": name,
                    "afbelding": afbeelding,
                    "prijs": prijs,
                    "afzet": 0
                }
                json_content[name] = subobject;

                fs.writeFile(filepath, JSON.stringify(json_content, null, 2), (error) => {
                    if (error) {
                        console.log(error);
                        return;
                    }
                    response.end('succes updated.')
                })
            })
        });

    } else if (regex3) {
        // console.log(regex3);
        fs.readFile(__dirname + '/frontent/product.json', (error, data) => {
            let jsdata = JSON.parse(data.toString());
            const searchParams = new URLSearchParams(request.url)
            let name0 = pathname.split('/');
            let name1 = name0[name0.length - 1];
            name1 = name1.replace(/%20/g, ' ');
            let name = searchParams.get(`/admin/edit/${name1}?name`);
            let prijs = searchParams.get('prijs');
            let afbeelding = searchParams.get('afbeelding');
            console.log('this is : name1', name1);
            console.log(name);
            delete jsdata[name1];
            jsdata[name] = {
                "productnaam": name,
                'prijs': prijs,
                'afbelding': afbeelding,
                'id': Date.now(),
                'afzet': 0
            }
            fs.writeFile(__dirname + '/frontent/product.json', JSON.stringify(jsdata, null, 2), (error) => {
                if (error) {
                    console.log(error);
                    return;
                }
                response.end('succes edited')
            })
        })
    } else if (regex4) {
        // console.log(regex3);
        fs.readFile(__dirname + '/frontent/product.json', (error, data) => {
            let jsdata = JSON.parse(data.toString());
            const searchParams = new URLSearchParams(request.url)
            let name0 = pathname.split('/');
            let name1 = name0[name0.length - 1];
            name1 = name1.replace(/%20/g, ' ');
            let name = searchParams.get(`/admin/edit/${name1}?name`);
            let prijs = searchParams.get('prijs');
            let afbeelding = searchParams.get('afbeelding');
            console.log('this is : name1', name1);
            console.log(name);
            delete jsdata[name1];
            fs.writeFile(__dirname + '/frontent/product.json', JSON.stringify(jsdata, null, 2), (error) => {
                if (error) {
                    console.log(error);
                    return;
                }
                response.end('succes removed')
            })
        })
    } else if (pathname == '/storage') {
        fs.readFile(__dirname + '/frontent/product.json', (error, data) => {
            let jsdata = JSON.parse(data.toString());
            fs.writeFile(__dirname + '/frontent/product-backup.json', JSON.stringify(jsdata, null, 2), (error) => {
                if (error) {
                    console.log(error);
                    return;
                }
                response.end('succes backuped')
            })
        })
    } else if (pathname == '/reset') {
        console.log(pathname);
        fs.readFile(__dirname + '/frontent/product-backup.json', (error, data) => {
            let jsdata = JSON.parse(data.toString());
            fs.writeFile(__dirname + '/frontent/product.json', JSON.stringify(jsdata, null, 2), (error) => {
                if (error) {
                    console.log(error);
                    return;
                }
                response.end('succes recalled')
            })
        })
    } else if (regex1) {
        let filepath = __dirname + '/frontent/user.json'
        console.log(regex1);
        fs.readFile(filepath, (error, data) => {
            if (error) {
                console.error('Error reading JSON file:', error);
                return;
            }
            let json_content = JSON.parse(data.toString())
            let currentTime = new Date();
            let year = currentTime.getFullYear();
            let month = currentTime.getMonth() + 1;
            let day = currentTime.getDate();
            let hours = currentTime.getHours();
            let minutes = currentTime.getMinutes();
            let seconds = currentTime.getSeconds();
            let amOrPm = hours >= 12 ? "PM" : "AM";
            if (hours > 12) {
                hours -= 12;
            }
            if (hours === 0) {
                hours = 12;
            }
            let formattedTime = hours + ":" + (minutes < 10 ? "0" : "") + minutes + ":" + (seconds < 10 ? "0" : "") + seconds + " " + amOrPm;
            let formattedDate = year + "-" + (month < 10 ? "0" : "") + month + "-" + (day < 10 ? "0" : "") + day;
            json_content.push([{ "id": json_content.length }, { "total": regex1[1] }, { "datum": formattedDate + " " + formattedTime }])
            fs.writeFile(filepath, JSON.stringify(json_content, null, 2), (error) => {
                if (error) {
                    console.log(error);
                    return;
                }
                response.end('succes updated.')
            })
        })
    } else if (regex2) {
        // console.log('regex2 is :' +regex2);
        regex2[1] = regex2[1].replace(/%20/g, ' ');
        fs.readFile(__dirname + '/frontent/product.json', (error, data) => {
            // console.log(JSON.parse(data.toString()));
            let name = JSON.parse(data.toString())[regex2[1]].productnaam;
            let prijs = JSON.parse(data.toString())[regex2[1]].prijs;
            let afbeelding = JSON.parse(data.toString())[regex2[1]].afbelding;
            var strVar = "";
            strVar += "<!DOCTYPE html>";
            strVar += "<html lang=\"en\">";
            strVar += "";
            strVar += "<head>";
            strVar += "    <meta charset=\"UTF-8\">";
            strVar += "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">";
            strVar += "    <title>Document<\/title>";
            strVar += "    <link href=\"https:\/\/cdn.jsdelivr.net\/npm\/bootstrap@5.3.2\/dist\/css\/bootstrap.min.css\" rel=\"stylesheet\"";
            strVar += "        integrity=\"sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV\/Dwwykc2MPK8M2HN\" crossorigin=\"anonymous\">";
            strVar += "<\/head>";
            strVar += "";
            strVar += "<body>";
            strVar += "    <nav class=\"navbar bg-body-tertiary\">";
            strVar += "        <div class=\"container\">";
            strVar += "            <a class=\"navbar-brand\">Admin Panel<\/a>";
            strVar += "            <div>";
            strVar += "                <a class=\"btn btn-outline-secondary border-0\" href=\"admin\" role=\"button\">orders<\/a>";
            strVar += "                <a class=\"btn btn-primary border-0\" role=\"button\" href=\"products.html\">products<\/a>";
            strVar += "            <\/div>";
            strVar += "        <\/div>";
            strVar += "    <\/nav>";
            strVar += "";
            strVar += "";
            strVar += "    <div class=\"container\">";
            strVar += "        <a href=\"../products.html\">Ga terug<\/a>";
            strVar += "        <h1>Edit your Product<\/h1>";
            strVar += `        <form action=\"\/admin\/edit\/${name}\">`;
            strVar += "            <div class=\"mb-3\">";
            strVar += "                <label for=\"exampleInputEmail1\" class=\"form-label\">Naam<\/label>";
            strVar += `                <input type=\"text\" class=\"form-control\" id=\"exampleInputEmail1\" aria-describedby=\"emailHelp\" value=\"${name}\" name=\"name\">`;
            strVar += "            <\/div>";
            strVar += "            <div class=\"mb-3\">";
            strVar += "                <label for=\"exampleInputPassword1\" class=\"form-label\">Prijs<\/label>";
            strVar += `                <input type=\"text\" class=\"form-control\" id=\"exampleInputPassword1\" value=\"${prijs}\" name=\"prijs\">`;
            strVar += "            <\/div>";
            strVar += "            <div class=\"mb-3\">";
            strVar += "                <label for=\"afbeelding\" class=\"form-label\">afbeelding<\/label>";
            strVar += "                <div class=\"row align-items-stretch m-0\">";
            strVar += "                    <div class=\"col-11 p-0\">";
            strVar += `                        <input type=\"text\" class=\"form-control\" id=\"afbeelding\" value=\"${afbeelding}\" name=\"afbeelding\">`;
            strVar += "                    <\/div>";
            strVar += "                    <button class=\"col-1 border-0 btn btn-secondary rounded-0\" type=\"button\" onclick=\"preview()\">preview<\/button>";
            strVar += "                <\/div>";
            strVar += "                <img style=\"max-height: 100px;\">";
            strVar += "            <\/div>";
            strVar += "            <button type=\"submit\" class=\"btn btn-primary\">Voeg toe<\/button>";
            strVar += "        <\/form>";
            strVar += "    <\/div>";
            strVar += "    <script>";
            strVar += "        function preview(){";
            strVar += "            let data = document.querySelector('#afbeelding').value;";
            strVar += "            document.querySelector('img').setAttribute('src',data)";
            strVar += "        }";
            strVar += "    <\/script>";
            strVar += "<\/body>";

            response.end(strVar)
        })
    } else if (request.url == '/clear/all') {
        let filepath = __dirname + '/frontent/winkelwagen.json'
        fs.readFile(filepath, (error, data) => {
            if (error) {
                console.error('Error reading JSON file:', error);
                return;
            }
            let json_content = JSON.parse(data.toString())

            for (const key in json_content.userid1.totalproduct) {
                json_content.userid1.totalproduct[key].afzet = 0;
            }

            fs.writeFile(filepath, JSON.stringify(json_content, null, 2), (error) => {
                if (error) {
                    console.log(error);
                    return;
                }
                response.end('succes updated.')
            })
        })
    } else {
        fs.readFile(readurl, (error, data) => {
            if (error) {
                response.statusCode = 404;
                response.end(error.message);
            } else {
                response.end(data);
            }
        });
    }
});

server.listen(8080, () => {
    console.log('Server is listening on port 8080');
});
